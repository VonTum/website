3D physics engine by
- Lennart Van Hirtum (physics)
- Matthias Vandersanden (graphics)


Controls:
	Simulation:
		p  			-  pause/unpause simulation
		t  			-  run one physics tick, makes the blocks move a little
		PAGE_UP		-  increase simulation speed
		PAGE_DOWN	-  decrease simulation speed
		
	Movement:
		zqsd		-  move horizontally		(works best on azerty, Use SHIFT-ALT to switch to azerty :P)
		SPACE/SHIFT	-  move up/down
		1/2			-  Change movement speed
		RMouse		-  rotate the camera
	
	World:
		LMouse		-  grab, select and move blocks
		o			-  create domino at center of the map
		DELETE		-  delete selected blocks
		
	Debug:
		F1			- toggle Yellow	(info) vectors
		F2			- toggle Red	(force) vectors
		F3			- toggle Orange	(moment) vectors
		F4			- toggle Purple	(impulse) vectors  (unused)
		F5			- toggle Blue	(collision) vectors
		F6			- toggle Green	(velocity) vectors


Have fun physicsing!

bugs and crashes may be rampant ;)
